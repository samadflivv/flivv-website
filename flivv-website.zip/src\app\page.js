import Home from '@/app/Home'
import Navigation from '@/components/Navigation'
import PopupModal from '@/components/PopupModal'
import React from 'react'

const page = () => {
  return (
    <>  
    <PopupModal/>
    <Home />
    </>
    
  )
}

export default page