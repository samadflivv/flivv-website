import React from 'react'

const HubspotForm = () => {
  return (
    <div className='border rounded-xl bg-white'>
        <script src="https://js.hsforms.net/forms/embed/21626983.js" defer></script>
<div class="hs-form-frame" data-region="na1" data-form-id="760bc3ed-5901-4e22-9d53-bdf02db591db" data-portal-id="21626983"></div>
    </div>
  )
}

export default HubspotForm